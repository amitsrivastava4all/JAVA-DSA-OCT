public class SumOfNnaturalNumber {
  // static void printName(int n){
  //   if(n == 0){
  //     return;
  //   }
  //   System.out.println("Yash");
  //   printName(n-1);
  // }
  static int sum(int n){
    if(n == 0)return n; 
    int s = sum(n-1);
    return n + s;
  }
  static void sum(int n , int sum){
    if(n == 0){
      System.out.println("Sum is " + sum);
      return;
    };
    sum += n;
    sum(n-1 , sum);
  }
  public static void main(String[] args) {
    // int sum = 0;
    // for(int i =1;i<=5;i++){
    //   sum += i;
    // }

    // System.out.println(sum);

    // printName(5);
    sum(5, 0);
    System.out.println(sum(5));
  }
  
}
