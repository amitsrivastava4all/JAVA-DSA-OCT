public class SumOfDigits {
  static int sod(int n){
    if(n == 0) return 0;
    int sum = sod(n /10);
    int rem = n % 10;
    sum += rem;
    return sum;
    
  }

  static void countDigits(int n , int count){
    if(n == 0){
      System.out.println("Count is " + count);
      return;
    }
    countDigits(n / 10, count + 1);
  } 

  static int countDigits(int n){
        if(n == 0)return 0;
       int count = countDigits(n/10);
       return  1 + count;
  }

  
  public static void main(String[] args) {
    int number = 12345;
    countDigits(number, 0);
    System.out.println("Count is " + countDigits(number));
    System.out.println(sod(number));
  }
  
}
