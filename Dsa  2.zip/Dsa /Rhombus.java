public class Rhombus {
  static void printRhombus(int n){
    for(int row = 0;row < n;row++){
      for(int space = 0;space < row;space++){
        System.out.print(" ");
      }

      for(int star = 0;star < n;star++){
        System.out.print("*");
      }
      System.out.println();
    }

    //recursive Code 

   
  }

  static void printSpace(int n){
    if(n == 0)return;
    System.out.print(" ");
    printSpace(n-1);
  }

  static void printStar(int n){
    if(n == 0)return;
    System.out.print("*");
    printStar(n-1);
  }

  static void printRow(int n , int space , int stars){
    if(n == 0) return;
    printSpace(space);
    printStar(stars);
    System.out.println();
    printRow(n-1 , space+1 , stars);
  }
  public static void main(String[] args) {
    int n = 5;
    // printRhombus(n);
    printRow(n, 0, n);


  }
  
}
