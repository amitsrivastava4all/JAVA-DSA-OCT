public class Factorial{

  static int fact(int n){
    if(n == 0) return 1;
    int factorial = fact(n-1);
    return n *factorial;

  }
  static void fact(int n , int fact){
    if(n == 0){
      System.out.println("Factorial is " + fact);
      return;
    }
    fact *=n;
    fact(n-1 ,fact);
  }

  
  public static void main(String[] args) {
    System.out.println(fact(5));
    fact(5 , 1);
  }
}