public class Pyramid {
  static void printPyramid(int n ){
    for(int row = 0;row<n;row++){
      for(int space = 0;space<n-row-1;space++){
        System.out.print(" ");
      }
      for(int star = 0;star<2*row+1;star++){
        System.out.print("*");
      }
      System.out.println();
    }
  }

  //Print Recursive 

  static void printRow(int n , int space , int stars){
    if(n == 0)return;
    printSpace(space);
    printStar(stars);
    System.out.println();
    printRow(n-1 , space -1 , stars +2);
  }

  static void printSpace(int n){
    if(n == 0)return;
    System.out.print(" ");
    printSpace(n-1);
  }

  static void printStar(int n){
    if(n == 0)return;
    System.out.print("*");
    printStar(n-1);
  }
  
  public static void main(String[] args) {

    
    int n = 5;
    // printPyramid(n);
    printRow(n, n, 1);

  }
  
}
