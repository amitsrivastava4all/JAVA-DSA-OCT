public class TriangleWithRecursion {
  static void printRow(int n){
    if(n == 0)return;
    printRow(n-1);
    printCol(n);
    System.out.println();

  }

  static void printCol(int n){
    if(n == 0)return;
    System.out.print("*");
    printCol(n-1);
  }
  public static void main(String[] args) {
    int n = 5;
    printRow(n);

  }
}
