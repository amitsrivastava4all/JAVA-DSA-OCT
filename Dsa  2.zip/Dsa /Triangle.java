public class Triangle {
  static void printTriangle(int n){
    for(int row = 0;row < n;row++){
      for(int col= 0;col<n-row;col++){
        System.out.print("*");
      }
      System.out.println();
    }
}

static void printStar(int n){
  if(n == 0)return;
  System.out.print("*");
  printStar(n-1);
}

  static void printRow(int n){
    if(n == 0)return;
    printStar(n);
    System.out.println();
    printRow(n - 1);
  }
  public static void main(String[] args) {
    int n = 5;
    printRow(n);
  }
  
}
