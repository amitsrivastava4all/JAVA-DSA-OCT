public class RecursionDemo{
  static int addTwoNumbers(int a , int b){
    return a + b;
  }

  public static void main(String[] args) {
    System.out.println(addTwoNumbers(10 , 20));
    System.out.println(addTwoNumbers(40 , 20));
  }
}