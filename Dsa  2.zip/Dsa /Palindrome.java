public class Palindrome {
  static void reverse(int n , int rev){
      if( n == 0){
        System.out.println("reverse is " + rev);
        return;
      }

      int rem = n % 10;
      rev = rev * 10 + rem;
      n = n/10;
      reverse(n, rev);
  }


  static int countDigits(int n){
    if(n == 0)return 0;
   int count = countDigits(n/10);
   System.out.println(1 + count);
   return  1 + count;
}

  static int reverse(int n){
    //Base Case 
    if(n <10 )return n;
    //Small Problem
    int rev = reverse(n /10);

    //<main Logic
    int rem = -
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    10;
    int position = (int)Math.pow(10 , countDigits(n)-1);
    return rem * position + rev;

  }
  public static void main(String[] args) {
    int n = 1234; 
    System.out.println(reverse(n));
  }
  
}
